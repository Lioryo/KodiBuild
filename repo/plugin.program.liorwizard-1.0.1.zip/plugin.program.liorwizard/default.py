# -*- coding: utf-8 -*-
import json
import os
import urllib.request
import zipfile

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

BASE_URL = "https://lioryo.github.io/KodiBuild/"
BUILDS_JSON = BASE_URL + "builds.json"


def t(path):
    return xbmcvfs.translatePath(path)


def download(url, dest):
    req = urllib.request.Request(url, headers={"User-Agent": "LiorKodiWizard/1.0"})
    with urllib.request.urlopen(req, timeout=60) as r, open(dest, "wb") as f:
        total = r.headers.get("Content-Length")
        total = int(total) if total else 0
        done = 0
        dp = xbmcgui.DialogProgress()
        dp.create("Lior Build", "מוריד Build...")
        while True:
            chunk = r.read(1024 * 256)
            if not chunk:
                break
            f.write(chunk)
            done += len(chunk)
            if total:
                dp.update(int(done * 100 / total))
            if dp.iscanceled():
                raise Exception("ההורדה בוטלה")
        dp.close()


def install_build(zip_path):
    home = PathLike(t("special://home"))
    dp = xbmcgui.DialogProgress()
    dp.create("Lior Build", "מתקין Build...")
    with zipfile.ZipFile(zip_path, "r") as zf:
        members = zf.infolist()
        for i, m in enumerate(members):
            if m.is_dir():
                continue
            target = os.path.join(home, m.filename.replace("/", os.sep))
            os.makedirs(os.path.dirname(target), exist_ok=True)
            with zf.open(m) as src, open(target, "wb") as dst:
                dst.write(src.read())
            if i % 20 == 0:
                dp.update(int(i * 100 / max(1, len(members))))
            if dp.iscanceled():
                raise Exception("ההתקנה בוטלה")
    dp.close()


def PathLike(s):
    return s


def main():
    dlg = xbmcgui.Dialog()
    try:
        with urllib.request.urlopen(BUILDS_JSON, timeout=30) as r:
            data = json.loads(r.read().decode("utf-8"))
        builds = data.get("builds", [])
        if not builds:
            dlg.ok("Lior Build", "לא נמצאו Builds")
            return
        labels = [b.get("name", "Build") + " " + b.get("version", "") for b in builds]
        idx = dlg.select("בחר Build להתקנה", labels)
        if idx < 0:
            return
        b = builds[idx]
        if not dlg.yesno("Lior Build", "להתקין את " + labels[idx] + "?", "מומלץ לגבות את Kodi לפני התקנה."):
            return
        packages = t("special://home/addons/packages")
        os.makedirs(packages, exist_ok=True)
        dest = os.path.join(packages, os.path.basename(b["url"]))
        download(b["url"], dest)
        install_build(dest)
        dlg.ok("Lior Build", "ההתקנה הסתיימה. סגור ופתח את Kodi מחדש.")
    except Exception as e:
        dlg.ok("Lior Build - שגיאה", str(e))

if __name__ == "__main__":
    main()
